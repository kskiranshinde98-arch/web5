

const apiKey = "YOUR_API_KEY_HERE"; // Replace with your OpenWeatherMap API key
const searchBtn = document.getElementById("searchBtn");
const currentLocationBtn = document.getElementById("currentLocationBtn");

const cityNameEl = document.getElementById("cityName");
const temperatureEl = document.getElementById("temperature");
const conditionEl = document.getElementById("condition");
const humidityEl = document.getElementById("humidity");
const windSpeedEl = document.getElementById("windSpeed");
const pressureEl = document.getElementById("pressure");

const feelsLikeEl = document.getElementById("feelsLike");
const minTempEl = document.getElementById("minTemp");
const maxTempEl = document.getElementById("maxTemp");
const visibilityEl = document.getElementById("visibility");

async function fetchWeatherByCity(city) {
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`;
    const response = await fetch(url);
    const data = await response.json();
    updateWeatherUI(data);
}

async function fetchWeatherByCoords(lat, lon) {
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=metric&appid=${apiKey}`;
    const response = await fetch(url);
    const data = await response.json();
    updateWeatherUI(data);
}

function updateWeatherUI(data) {
    if (data.cod !== 200) {
        alert("City not found!");
        return;
    }

    cityNameEl.textContent = data.name + ", " + data.sys.country;
    temperatureEl.textContent = "Temperature: " + data.main.temp + " °C";
    conditionEl.textContent = "Condition: " + data.weather[0].description;
    humidityEl.textContent = "Humidity: " + data.main.humidity + " %";
    windSpeedEl.textContent = "Wind Speed: " + data.wind.speed + " m/s";
    pressureEl.textContent = "Pressure: " + data.main.pressure + " hPa";

    feelsLikeEl.textContent = data.main.feels_like + " °C";
    minTempEl.textContent = data.main.temp_min + " °C";
    maxTempEl.textContent = data.main.temp_max + " °C";
    visibilityEl.textContent = data.visibility + " m";
}

searchBtn.addEventListener("click", () => {
    const city = document.getElementById("locationInput").value;
    if (city) {
        fetchWeatherByCity(city);
    }
});

currentLocationBtn.addEventListener("click", () => {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(position => {
            const lat = position.coords.latitude;
            const lon = position.coords.longitude;
            fetchWeatherByCoords(lat, lon);
        });
    } else {
        alert("Geolocation not supported.");
    }
});
